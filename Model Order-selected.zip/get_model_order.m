function [ modelOrder ] = get_model_order( displayString )
% input is the string that is displayed to represent the vowel
% output is an integer which is the model order to use as a parameter to
% the function to calculate formants

% assumes model order data structure

if isKey(displayString)
    modelOrder = moMap(displayString);
else
    modelOrder = -1;
end
 

end

