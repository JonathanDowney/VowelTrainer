function [  ] = Record( filename, durationSecs )
%RECORD Summary of this function goes here
%   Detailed explanation goes here
Fs = 44100;
%durationSecs = 2;
recorder = audiorecorder(Fs,16,1);

disp('Begin Signal Input...')
% start the recording
record(recorder,durationSecs);

pause(durationSecs+.5);
% do not exit function until the figure has been deleted
audio_rec = getaudiodata(recorder);
disp('End Signal Input')

audiowrite(filename, audio_rec, Fs);


end

