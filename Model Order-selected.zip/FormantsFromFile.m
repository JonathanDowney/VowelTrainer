function [ f1output, f2output ] = FormantsFromFile( filename, Fs, mo )
y = audioread(filename);
startIndexOfWord = 1;
while y(startIndexOfWord) < max(y) * .2
    startIndexOfWord = startIndexOfWord+1;
end
endIndexOfWord = size(y,1);
while y(endIndexOfWord) < max(y)* .2
    endIndexOfWord = endIndexOfWord-1;
end

%f0values = zeros(ceil((endIndexOfWord-startIndexOfWord)/50), 1);
f3values = zeros(ceil((endIndexOfWord-startIndexOfWord)/200), 1);
f2values = zeros(ceil((endIndexOfWord-startIndexOfWord)/200), 1);

f1values = zeros(ceil((endIndexOfWord-startIndexOfWord)/200), 1);
f1indices = zeros(ceil((endIndexOfWord-startIndexOfWord)/200), 1);

nextFormantIndex = 1;
for i = startIndexOfWord:200:(endIndexOfWord - 200)
    %[f0, f1, f2, f3] = FormantsFromClip(y(i:i+20));
    [f1, f2, f3] = FormantsFromClip2(y(i:i+200), Fs, mo);
    f1values(nextFormantIndex) = f1;
    f1indices(nextFormantIndex) = i;
    %f0values(nextFormantIndex) = f0;
    f2values(nextFormantIndex) = f2;
    f3values(nextFormantIndex) = f3;
    nextFormantIndex = nextFormantIndex + 1;
end

startIndexOfVowel = 1;
endIndexOfVowel = 1;
newStart = 1;
newEnd = 1;

i = 2;
while (i < size(f1values,1))
    if (abs(f1values(i-1)-f1values(i)) < 200)
        newEnd = i;
    else
        if (newEnd - newStart > endIndexOfVowel - startIndexOfVowel)
            endIndexOfVowel = newEnd;
            startIndexOfVowel = newStart;
        end
        newStart = i;
        newEnd = i;
    end
        i = i + 1;
end

if (newEnd - newStart > endIndexOfVowel - startIndexOfVowel)
    endIndexOfVowel = newEnd;
    startIndexOfVowel = newStart;
end

f1output = 0;
f2output = 0;
f1output = median(f1values(startIndexOfVowel:endIndexOfVowel));
f2output = median(f2values(startIndexOfVowel:endIndexOfVowel));
end

