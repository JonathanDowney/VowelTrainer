fid = fopen('vowelModelOrders.txt', 'r');
modelOrders = textscan(fid, '%s %s %d');
moMap = containers.Map(modelOrders{1}, modelOrders{3});