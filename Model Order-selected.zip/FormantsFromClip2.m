function [ f1, f2, f3 ] = FormantsFromClip2( x, fs, modelOrder )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

x1 = resample(x, 1, 4);




fs = (1/4) * fs;
A = lpc(x1,modelOrder);
rts = roots(A);

%%
% Because the LPC coefficients are real-valued, the roots occur in complex
% conjugate pairs. Retain only the roots with one sign for the imaginary
% part and determine the angles corresponding to the roots.

rts = rts(imag(rts)>=0);
angz = atan2(imag(rts),real(rts));

%%
% Convert the angular frequencies in rad/sample represented by the
% angles to Hz and calculate the bandwidths of the formants.
%
% The bandwidths of the formants are represented by the distance of the
% prediction polynomial zeros from the unit circle.

[frqs,indices] = sort(angz.*(fs/(2*pi)));
bw = -1/2*(fs/(2*pi))*log(abs(rts(indices)));

%%
% Use the criterion that formant frequencies should be greater than 90 Hz
% with bandwidths less than 400 Hz to determine the formants.
nn = 1;
formants = [ 0 0 0 ];
for kk = 1:length(frqs)
    %% this if statement hasn't been helpful to me, but was in the original
    %% code.
    if (frqs(kk) > 90 && bw(kk) <400)
    %if (frqs(kk) > 90 )
        formants(nn) = frqs(kk);
        nn = nn+1;
    %end
    end

end

f1 = formants(1);
f2 = formants(2);
f3 = formants(3);

end

