function val = rms(vec,len)

val=norm(vec,2)/sqrt(len);


