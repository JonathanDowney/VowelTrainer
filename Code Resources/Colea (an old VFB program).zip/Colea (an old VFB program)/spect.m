function spect (x)


 psd(x)
