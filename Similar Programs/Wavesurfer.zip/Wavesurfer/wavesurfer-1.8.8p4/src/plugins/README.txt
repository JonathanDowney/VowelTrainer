This directory contains a number of example plug-ins showing how
the WaveSurfer plugin API can be used.

Move these files to
 wsurf1.8/plugins/
or to
 ~/.wavesurfer/1.8/plugins/
in order to use them.


example1.plug
Simple example that adds a pane showing voicing info.


example2.plug
Extension of the previous that adds a properties dialog

